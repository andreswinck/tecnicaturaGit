/*
 * Testiando Jugador
 * 
 */
package test;

import trivia.Jugador;
import trivia.Preguntas;
import trivia.Titulos;
import trivia.CalcularGanador;

/**
 *
 * @author Nico
 */
public class TestJugador {
    public static void main(String[] args) {
        Titulos inicio = new Titulos();
        Jugador nombre=new Jugador();
        CalcularGanador modo=new CalcularGanador();
        Preguntas pregunta=new Preguntas();
        
        
        inicio.comienzoPresentacion();
        nombre.guardarNombre();
              
        pregunta.cargarPreguntas();
        pregunta.mostrarPregunta();
        modo.CalculoGanador();
        
    }
    
    
}
