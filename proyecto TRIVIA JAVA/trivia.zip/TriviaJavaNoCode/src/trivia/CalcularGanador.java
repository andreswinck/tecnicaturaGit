package trivia;


import javax.swing.JOptionPane;

/*
 * 
package trivia;

/**
 *
 * @author no code
 */
public class CalcularGanador extends Jugador{
    public String ganador;
    public String puntos;
    public int correcto = 150;
    public int incorrecto;
    public int resultado;
    public CalcularGanador() {
    }
    
    public CalcularGanador(String nombreJugador, String puntoJugador) {
       super(nombreJugador, puntoJugador);
       this.ganador = nombreJugador;
       this.puntos = puntoJugador;
    }
    
    public void CalculoGanador(){
        Preguntas puntos=new Preguntas();
        correcto = puntos.getCorrectas();
        incorrecto = puntos.getIncorrectas();
        resultado=correcto-incorrecto;
        if (correcto >= 70) {
            System.out.println("you win");
            Titulos ganaste=new Titulos();
            ganaste.youWin();
        } else {
            System.out.println("you lose");
            Titulos perdiste =new Titulos();
            perdiste.youLose();
        }
        
    }

    
    
    
    
}
